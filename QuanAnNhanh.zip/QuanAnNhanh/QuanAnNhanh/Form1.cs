﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace QuanAnNhanh
{
    public partial class Form1 : Form
    {
        private readonly Dictionary<string, int> orders =
            new Dictionary<string, int>(StringComparer.CurrentCulture);

        public Form1()
        {
            InitializeComponent(); // KHÔNG tạo nút ở đây để tránh lỗi Designer
        }

        private void MonAn_Click(object sender, EventArgs e)
        {
            if (sender is Button b)
            {
                string tenMon = b.Text;
                if (orders.ContainsKey(tenMon)) orders[tenMon]++;
                else orders[tenMon] = 1;
                CapNhatGrid();
            }
        }

        private void CapNhatGrid()
        {
            dgvOrders.Rows.Clear();
            foreach (var kv in orders)
                dgvOrders.Rows.Add(kv.Key, kv.Value);
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            orders.Clear();
            dgvOrders.Rows.Clear();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            if (cbBan.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng chọn bàn!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (orders.Count == 0)
            {
                MessageBox.Show("Chưa có món nào được chọn!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string fileName = $"orders_{DateTime.Now:yyyyMMdd}.txt";
            using (var sw = new StreamWriter(fileName, true))
            {
                sw.WriteLine("========== ĐƠN GỌI MÓN ==========");
                sw.WriteLine($"Bàn: {cbBan.SelectedItem}");
                sw.WriteLine($"Thời gian: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                sw.WriteLine("---------------------------------");
                foreach (var kv in orders)
                    sw.WriteLine($"{kv.Key,-25} x{kv.Value}");
                sw.WriteLine();
            }

            MessageBox.Show($"Đã lưu đơn hàng vào file {fileName}",
                "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
            orders.Clear();
            dgvOrders.Rows.Clear();
        }
    }
}
