﻿namespace QuanAnNhanh
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        // Header
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTitle;

        // Menu
        private System.Windows.Forms.GroupBox grpMenu;
        private System.Windows.Forms.TableLayoutPanel tlpMenu;

        // 15 nút món (tạo sẵn để Designer không lỗi)
        private System.Windows.Forms.Button btnComChienTrung;
        private System.Windows.Forms.Button btnBanhMiOpla;
        private System.Windows.Forms.Button btnCoca;
        private System.Windows.Forms.Button btnLipton;
        private System.Windows.Forms.Button btnOcRangMuoi;
        private System.Windows.Forms.Button btnKhoaiTayChien;
        private System.Windows.Forms.Button btn7up;
        private System.Windows.Forms.Button btnCam;
        private System.Windows.Forms.Button btnMyXaoHaiSan;
        private System.Windows.Forms.Button btnCaVienChien;
        private System.Windows.Forms.Button btnPepsi;
        private System.Windows.Forms.Button btnCafe;
        private System.Windows.Forms.Button btnBurgerBoNuong;
        private System.Windows.Forms.Button btnDuiGaRan;
        private System.Windows.Forms.Button btnBunBoHue;

        // Action row
        private System.Windows.Forms.Panel pnlAction;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Label lblChonBan;
        private System.Windows.Forms.ComboBox cbBan;
        private System.Windows.Forms.Button btnOrder;

        // Grid
        private System.Windows.Forms.DataGridView dgvOrders;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenMon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoLuong;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpMenu = new System.Windows.Forms.GroupBox();
            this.tlpMenu = new System.Windows.Forms.TableLayoutPanel();
            this.btnComChienTrung = new System.Windows.Forms.Button();
            this.btnBanhMiOpla = new System.Windows.Forms.Button();
            this.btnCoca = new System.Windows.Forms.Button();
            this.btnLipton = new System.Windows.Forms.Button();
            this.btnOcRangMuoi = new System.Windows.Forms.Button();
            this.btnKhoaiTayChien = new System.Windows.Forms.Button();
            this.btn7up = new System.Windows.Forms.Button();
            this.btnCam = new System.Windows.Forms.Button();
            this.btnMyXaoHaiSan = new System.Windows.Forms.Button();
            this.btnCaVienChien = new System.Windows.Forms.Button();
            this.btnPepsi = new System.Windows.Forms.Button();
            this.btnCafe = new System.Windows.Forms.Button();
            this.btnBurgerBoNuong = new System.Windows.Forms.Button();
            this.btnDuiGaRan = new System.Windows.Forms.Button();
            this.btnBunBoHue = new System.Windows.Forms.Button();
            this.pnlAction = new System.Windows.Forms.Panel();
            this.btnXoa = new System.Windows.Forms.Button();
            this.lblChonBan = new System.Windows.Forms.Label();
            this.cbBan = new System.Windows.Forms.ComboBox();
            this.btnOrder = new System.Windows.Forms.Button();
            this.dgvOrders = new System.Windows.Forms.DataGridView();
            this.colTenMon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpMenu.SuspendLayout();
            this.tlpMenu.SuspendLayout();
            this.pnlAction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlHeader.Controls.Add(this.pictureBox1);
            this.pnlHeader.Controls.Add(this.lblTitle);
            this.pnlHeader.Location = new System.Drawing.Point(8, 8);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(504, 86);
            this.pnlHeader.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(8, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.ForestGreen;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(124, 8);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(370, 70);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Quán ăn nhanh Hưng Thịnh";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpMenu
            // 
            this.grpMenu.Controls.Add(this.tlpMenu);
            this.grpMenu.Location = new System.Drawing.Point(8, 100);
            this.grpMenu.Name = "grpMenu";
            this.grpMenu.Size = new System.Drawing.Size(504, 170);
            this.grpMenu.TabIndex = 1;
            this.grpMenu.TabStop = false;
            this.grpMenu.Text = "Danh sách món ăn:";
            // 
            // tlpMenu
            // 
            this.tlpMenu.ColumnCount = 4;
            this.tlpMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.Controls.Add(this.btnComChienTrung, 0, 0);
            this.tlpMenu.Controls.Add(this.btnBanhMiOpla, 1, 0);
            this.tlpMenu.Controls.Add(this.btnCoca, 2, 0);
            this.tlpMenu.Controls.Add(this.btnLipton, 3, 0);
            this.tlpMenu.Controls.Add(this.btnOcRangMuoi, 0, 1);
            this.tlpMenu.Controls.Add(this.btnKhoaiTayChien, 1, 1);
            this.tlpMenu.Controls.Add(this.btn7up, 2, 1);
            this.tlpMenu.Controls.Add(this.btnCam, 3, 1);
            this.tlpMenu.Controls.Add(this.btnMyXaoHaiSan, 0, 2);
            this.tlpMenu.Controls.Add(this.btnCaVienChien, 1, 2);
            this.tlpMenu.Controls.Add(this.btnPepsi, 2, 2);
            this.tlpMenu.Controls.Add(this.btnCafe, 3, 2);
            this.tlpMenu.Controls.Add(this.btnBurgerBoNuong, 0, 3);
            this.tlpMenu.Controls.Add(this.btnDuiGaRan, 1, 3);
            this.tlpMenu.Controls.Add(this.btnBunBoHue, 2, 3);
            this.tlpMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpMenu.Location = new System.Drawing.Point(3, 18);
            this.tlpMenu.Name = "tlpMenu";
            this.tlpMenu.Padding = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.tlpMenu.RowCount = 4;
            this.tlpMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.Size = new System.Drawing.Size(498, 149);
            this.tlpMenu.TabIndex = 0;
            // 
            // btnComChienTrung
            // 
            this.btnComChienTrung.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnComChienTrung.Location = new System.Drawing.Point(16, 14);
            this.btnComChienTrung.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnComChienTrung.Name = "btnComChienTrung";
            this.btnComChienTrung.Size = new System.Drawing.Size(101, 21);
            this.btnComChienTrung.TabIndex = 0;
            this.btnComChienTrung.Text = "Cơm chiên trứng";
            this.btnComChienTrung.UseVisualStyleBackColor = true;
            this.btnComChienTrung.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnBanhMiOpla
            // 
            this.btnBanhMiOpla.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBanhMiOpla.Location = new System.Drawing.Point(137, 14);
            this.btnBanhMiOpla.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnBanhMiOpla.Name = "btnBanhMiOpla";
            this.btnBanhMiOpla.Size = new System.Drawing.Size(101, 21);
            this.btnBanhMiOpla.TabIndex = 1;
            this.btnBanhMiOpla.Text = "Bánh mì ốp la";
            this.btnBanhMiOpla.UseVisualStyleBackColor = true;
            this.btnBanhMiOpla.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnCoca
            // 
            this.btnCoca.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCoca.Location = new System.Drawing.Point(258, 14);
            this.btnCoca.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnCoca.Name = "btnCoca";
            this.btnCoca.Size = new System.Drawing.Size(101, 21);
            this.btnCoca.TabIndex = 2;
            this.btnCoca.Text = "Coca";
            this.btnCoca.UseVisualStyleBackColor = true;
            this.btnCoca.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnLipton
            // 
            this.btnLipton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLipton.Location = new System.Drawing.Point(379, 14);
            this.btnLipton.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnLipton.Name = "btnLipton";
            this.btnLipton.Size = new System.Drawing.Size(103, 21);
            this.btnLipton.TabIndex = 3;
            this.btnLipton.Text = "Lipton";
            this.btnLipton.UseVisualStyleBackColor = true;
            this.btnLipton.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnOcRangMuoi
            // 
            this.btnOcRangMuoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnOcRangMuoi.Location = new System.Drawing.Point(16, 47);
            this.btnOcRangMuoi.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnOcRangMuoi.Name = "btnOcRangMuoi";
            this.btnOcRangMuoi.Size = new System.Drawing.Size(101, 21);
            this.btnOcRangMuoi.TabIndex = 4;
            this.btnOcRangMuoi.Text = "Ốc rang muối";
            this.btnOcRangMuoi.UseVisualStyleBackColor = true;
            this.btnOcRangMuoi.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnKhoaiTayChien
            // 
            this.btnKhoaiTayChien.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnKhoaiTayChien.Location = new System.Drawing.Point(137, 47);
            this.btnKhoaiTayChien.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnKhoaiTayChien.Name = "btnKhoaiTayChien";
            this.btnKhoaiTayChien.Size = new System.Drawing.Size(101, 21);
            this.btnKhoaiTayChien.TabIndex = 5;
            this.btnKhoaiTayChien.Text = "Khoai tây chiên";
            this.btnKhoaiTayChien.UseVisualStyleBackColor = true;
            this.btnKhoaiTayChien.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btn7up
            // 
            this.btn7up.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn7up.Location = new System.Drawing.Point(258, 47);
            this.btn7up.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btn7up.Name = "btn7up";
            this.btn7up.Size = new System.Drawing.Size(101, 21);
            this.btn7up.TabIndex = 6;
            this.btn7up.Text = "7 up";
            this.btn7up.UseVisualStyleBackColor = true;
            this.btn7up.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnCam
            // 
            this.btnCam.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCam.Location = new System.Drawing.Point(379, 47);
            this.btnCam.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnCam.Name = "btnCam";
            this.btnCam.Size = new System.Drawing.Size(103, 21);
            this.btnCam.TabIndex = 7;
            this.btnCam.Text = "Cam";
            this.btnCam.UseVisualStyleBackColor = true;
            this.btnCam.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnMyXaoHaiSan
            // 
            this.btnMyXaoHaiSan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnMyXaoHaiSan.Location = new System.Drawing.Point(16, 80);
            this.btnMyXaoHaiSan.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnMyXaoHaiSan.Name = "btnMyXaoHaiSan";
            this.btnMyXaoHaiSan.Size = new System.Drawing.Size(101, 21);
            this.btnMyXaoHaiSan.TabIndex = 8;
            this.btnMyXaoHaiSan.Text = "Mỳ xào hải sản";
            this.btnMyXaoHaiSan.UseVisualStyleBackColor = true;
            this.btnMyXaoHaiSan.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnCaVienChien
            // 
            this.btnCaVienChien.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCaVienChien.Location = new System.Drawing.Point(137, 80);
            this.btnCaVienChien.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnCaVienChien.Name = "btnCaVienChien";
            this.btnCaVienChien.Size = new System.Drawing.Size(101, 21);
            this.btnCaVienChien.TabIndex = 9;
            this.btnCaVienChien.Text = "Cá viên chiên";
            this.btnCaVienChien.UseVisualStyleBackColor = true;
            this.btnCaVienChien.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnPepsi
            // 
            this.btnPepsi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPepsi.Location = new System.Drawing.Point(258, 80);
            this.btnPepsi.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnPepsi.Name = "btnPepsi";
            this.btnPepsi.Size = new System.Drawing.Size(101, 21);
            this.btnPepsi.TabIndex = 10;
            this.btnPepsi.Text = "Pepsi";
            this.btnPepsi.UseVisualStyleBackColor = true;
            this.btnPepsi.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnCafe
            // 
            this.btnCafe.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCafe.Location = new System.Drawing.Point(379, 80);
            this.btnCafe.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnCafe.Name = "btnCafe";
            this.btnCafe.Size = new System.Drawing.Size(103, 21);
            this.btnCafe.TabIndex = 11;
            this.btnCafe.Text = "Cafe";
            this.btnCafe.UseVisualStyleBackColor = true;
            this.btnCafe.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnBurgerBoNuong
            // 
            this.btnBurgerBoNuong.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBurgerBoNuong.Location = new System.Drawing.Point(16, 113);
            this.btnBurgerBoNuong.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnBurgerBoNuong.Name = "btnBurgerBoNuong";
            this.btnBurgerBoNuong.Size = new System.Drawing.Size(101, 22);
            this.btnBurgerBoNuong.TabIndex = 12;
            this.btnBurgerBoNuong.Text = "Buger bò nướng";
            this.btnBurgerBoNuong.UseVisualStyleBackColor = true;
            this.btnBurgerBoNuong.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnDuiGaRan
            // 
            this.btnDuiGaRan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDuiGaRan.Location = new System.Drawing.Point(137, 113);
            this.btnDuiGaRan.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnDuiGaRan.Name = "btnDuiGaRan";
            this.btnDuiGaRan.Size = new System.Drawing.Size(101, 22);
            this.btnDuiGaRan.TabIndex = 13;
            this.btnDuiGaRan.Text = "Đùi gà rán";
            this.btnDuiGaRan.UseVisualStyleBackColor = true;
            this.btnDuiGaRan.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // btnBunBoHue
            // 
            this.btnBunBoHue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBunBoHue.Location = new System.Drawing.Point(258, 113);
            this.btnBunBoHue.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.btnBunBoHue.Name = "btnBunBoHue";
            this.btnBunBoHue.Size = new System.Drawing.Size(101, 22);
            this.btnBunBoHue.TabIndex = 14;
            this.btnBunBoHue.Text = "Bún bò Huế";
            this.btnBunBoHue.UseVisualStyleBackColor = true;
            this.btnBunBoHue.Click += new System.EventHandler(this.MonAn_Click);
            // 
            // pnlAction
            // 
            this.pnlAction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAction.Controls.Add(this.btnXoa);
            this.pnlAction.Controls.Add(this.lblChonBan);
            this.pnlAction.Controls.Add(this.cbBan);
            this.pnlAction.Controls.Add(this.btnOrder);
            this.pnlAction.Location = new System.Drawing.Point(8, 274);
            this.pnlAction.Name = "pnlAction";
            this.pnlAction.Size = new System.Drawing.Size(504, 40);
            this.pnlAction.TabIndex = 2;
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(10, 6);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(70, 26);
            this.btnXoa.TabIndex = 0;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // lblChonBan
            // 
            this.lblChonBan.AutoSize = true;
            this.lblChonBan.Location = new System.Drawing.Point(110, 10);
            this.lblChonBan.Name = "lblChonBan";
            this.lblChonBan.Size = new System.Drawing.Size(67, 16);
            this.lblChonBan.TabIndex = 1;
            this.lblChonBan.Text = "Chọn bàn:";
            // 
            // cbBan
            // 
            this.cbBan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBan.Items.AddRange(new object[] {
            "Bàn 1",
            "Bàn 2",
            "Bàn 3",
            "Bàn 4",
            "Bàn 5",
            "Bàn 6",
            "Bàn 7",
            "Bàn 8"});
            this.cbBan.Location = new System.Drawing.Point(175, 7);
            this.cbBan.Name = "cbBan";
            this.cbBan.Size = new System.Drawing.Size(160, 24);
            this.cbBan.TabIndex = 2;
            // 
            // btnOrder
            // 
            this.btnOrder.Location = new System.Drawing.Point(420, 6);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(70, 26);
            this.btnOrder.TabIndex = 3;
            this.btnOrder.Text = "Order";
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // dgvOrders
            // 
            this.dgvOrders.AllowUserToAddRows = false;
            this.dgvOrders.AllowUserToDeleteRows = false;
            this.dgvOrders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvOrders.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dgvOrders.ColumnHeadersHeight = 29;
            this.dgvOrders.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTenMon,
            this.colSoLuong});
            this.dgvOrders.Location = new System.Drawing.Point(8, 318);
            this.dgvOrders.Name = "dgvOrders";
            this.dgvOrders.ReadOnly = true;
            this.dgvOrders.RowHeadersVisible = false;
            this.dgvOrders.RowHeadersWidth = 51;
            this.dgvOrders.Size = new System.Drawing.Size(504, 230);
            this.dgvOrders.TabIndex = 3;
            // 
            // colTenMon
            // 
            this.colTenMon.HeaderText = "Tên món";
            this.colTenMon.MinimumWidth = 220;
            this.colTenMon.Name = "colTenMon";
            this.colTenMon.ReadOnly = true;
            // 
            // colSoLuong
            // 
            this.colSoLuong.HeaderText = "Số lượng";
            this.colSoLuong.MinimumWidth = 80;
            this.colSoLuong.Name = "colSoLuong";
            this.colSoLuong.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(520, 560);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.grpMenu);
            this.Controls.Add(this.pnlAction);
            this.Controls.Add(this.dgvOrders);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnlHeader.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpMenu.ResumeLayout(false);
            this.tlpMenu.ResumeLayout(false);
            this.pnlAction.ResumeLayout(false);
            this.pnlAction.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion
    }
}
