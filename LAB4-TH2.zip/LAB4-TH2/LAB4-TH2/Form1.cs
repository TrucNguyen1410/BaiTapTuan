﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LAB4_TH2
{
    public partial class Form1 : Form
    {
        // 🔹 Chuỗi kết nối đến SQL Server
        string strCon = @"Data Source=DESKTOP-AV9ONFH\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True;";
        SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        // 🔹 Khi nhấn nút "Số lượng sinh viên"
        private void btnCount_Click(object sender, EventArgs e)
        {
            try
            {
                // Mở kết nối
                if (sqlCon == null)
                    sqlCon = new SqlConnection(strCon);
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                // Tạo truy vấn SQL
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "SELECT COUNT(*) FROM SinhVien";
                sqlCmd.Connection = sqlCon;

                // Thực thi và lấy kết quả
                int soLuongSV = (int)sqlCmd.ExecuteScalar();

                // Hiển thị
                MessageBox.Show("Số lượng sinh viên là: " + soLuongSV, "Kết quả");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo");
            }
        }
    }
}
