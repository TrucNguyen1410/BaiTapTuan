﻿namespace LAB4_TH2
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code giao diện Form2

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtMaSV = new System.Windows.Forms.TextBox();
            this.btnXemThongTin = new System.Windows.Forms.Button();
            this.txtTenSV = new System.Windows.Forms.TextBox();
            this.txtGioiTinh = new System.Windows.Forms.TextBox();
            this.txtNgaySinh = new System.Windows.Forms.TextBox();
            this.txtQueQuan = new System.Windows.Forms.TextBox();
            this.txtMaLop = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Text = "Nhập mã sinh viên:";
            this.label1.Location = new System.Drawing.Point(30, 30);
            this.label1.AutoSize = true;
            // 
            // txtMaSV
            // 
            this.txtMaSV.Location = new System.Drawing.Point(160, 27);
            this.txtMaSV.Size = new System.Drawing.Size(200, 27);
            // 
            // btnXemThongTin
            // 
            this.btnXemThongTin.Location = new System.Drawing.Point(100, 70);
            this.btnXemThongTin.Size = new System.Drawing.Size(200, 35);
            this.btnXemThongTin.Text = "Xem thông tin chi tiết";
            this.btnXemThongTin.Click += new System.EventHandler(this.btnXemThongTin_Click);
            // 
            // Các label và textbox thông tin sinh viên
            // 
            this.label2.Text = "Tên sinh viên:";
            this.label2.Location = new System.Drawing.Point(30, 130);
            this.label2.AutoSize = true;

            this.txtTenSV.Location = new System.Drawing.Point(160, 127);
            this.txtTenSV.Size = new System.Drawing.Size(200, 27);

            this.label3.Text = "Giới tính:";
            this.label3.Location = new System.Drawing.Point(30, 170);
            this.label3.AutoSize = true;

            this.txtGioiTinh.Location = new System.Drawing.Point(160, 167);
            this.txtGioiTinh.Size = new System.Drawing.Size(200, 27);

            this.label4.Text = "Ngày sinh:";
            this.label4.Location = new System.Drawing.Point(30, 210);
            this.label4.AutoSize = true;

            this.txtNgaySinh.Location = new System.Drawing.Point(160, 207);
            this.txtNgaySinh.Size = new System.Drawing.Size(200, 27);

            this.label5.Text = "Quê quán:";
            this.label5.Location = new System.Drawing.Point(30, 250);
            this.label5.AutoSize = true;

            this.txtQueQuan.Location = new System.Drawing.Point(160, 247);
            this.txtQueQuan.Size = new System.Drawing.Size(200, 27);

            this.label6.Text = "Mã lớp:";
            this.label6.Location = new System.Drawing.Point(30, 290);
            this.label6.AutoSize = true;

            this.txtMaLop.Location = new System.Drawing.Point(160, 287);
            this.txtMaLop.Size = new System.Drawing.Size(200, 27);

            // 
            // Form2
            // 
            this.ClientSize = new System.Drawing.Size(420, 360);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMaSV);
            this.Controls.Add(this.btnXemThongTin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTenSV);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtGioiTinh);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNgaySinh);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtQueQuan);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtMaLop);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thực hiện truy vấn 1 dòng dữ liệu";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMaSV;
        private System.Windows.Forms.Button btnXemThongTin;
        private System.Windows.Forms.TextBox txtTenSV;
        private System.Windows.Forms.TextBox txtGioiTinh;
        private System.Windows.Forms.TextBox txtNgaySinh;
        private System.Windows.Forms.TextBox txtQueQuan;
        private System.Windows.Forms.TextBox txtMaLop;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}
