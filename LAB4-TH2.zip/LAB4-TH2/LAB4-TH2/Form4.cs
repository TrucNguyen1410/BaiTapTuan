﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LAB4_TH2
{
    public partial class Form4 : Form
    {
        // 🔹 Chuỗi kết nối SQL Server (sửa lại tên máy bạn nếu khác)
        string strCon = @"Data Source=DESKTOP-AV9ONFH\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True;";
        SqlConnection sqlCon = null;

        public Form4()
        {
            InitializeComponent();
        }

        // 🔹 Khi nhấn nút “Xem danh sách lớp”
        private void btnXemDS_Click(object sender, EventArgs e)
        {
            try
            {
                // Mở kết nối
                if (sqlCon == null)
                    sqlCon = new SqlConnection(strCon);
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                // Xóa dữ liệu cũ
                lsvDanhSach.Items.Clear();

                // Lấy tên khoa từ textbox
                string tenKhoa = txtTenKhoa.Text.Trim();
                string maKhoa = "";

                // Gán mã khoa theo tên khoa
                if (tenKhoa == "Công nghệ thông tin")
                    maKhoa = "CNTT";
                else if (tenKhoa == "Kinh tế")
                    maKhoa = "KT";
                else if (tenKhoa == "Điện tử")
                    maKhoa = "DT";
                else
                {
                    MessageBox.Show("Tên khoa không hợp lệ!", "Thông báo");
                    return;
                }

                // Tạo truy vấn SQL có Parameter
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "SELECT * FROM Lop WHERE MaKhoa = @maKhoa";
                sqlCmd.Parameters.AddWithValue("@maKhoa", maKhoa);
                sqlCmd.Connection = sqlCon;

                // Thực thi truy vấn
                SqlDataReader reader = sqlCmd.ExecuteReader();

                while (reader.Read())
                {
                    string maLop = reader.GetString(0);
                    string tenLop = reader.GetString(1);
                    string mk = reader.GetString(2);

                    // Thêm vào ListView
                    ListViewItem lvi = new ListViewItem(maLop);
                    lvi.SubItems.Add(tenLop);
                    lvi.SubItems.Add(mk);
                    lsvDanhSach.Items.Add(lvi);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo");
            }
        }
    }
}
