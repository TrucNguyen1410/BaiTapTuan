﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LAB4_TH2
{
    public partial class Form2 : Form
    {
        // 🔹 Chuỗi kết nối SQL Server (sửa lại cho đúng tên máy bạn)
        string strCon = @"Data Source=DESKTOP-AV9ONFH\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True;";
        SqlConnection sqlCon = null;

        public Form2()
        {
            InitializeComponent();
        }

        // 🔹 Khi nhấn nút "Xem thông tin chi tiết"
        private void btnXemThongTin_Click(object sender, EventArgs e)
        {
            try
            {
                // Mở kết nối
                if (sqlCon == null)
                    sqlCon = new SqlConnection(strCon);
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                // Lấy mã sinh viên từ textbox
                string maSV = txtMaSV.Text.Trim();

                if (string.IsNullOrEmpty(maSV))
                {
                    MessageBox.Show("Vui lòng nhập mã sinh viên!", "Thông báo");
                    return;
                }

                // Tạo lệnh truy vấn
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "SELECT * FROM SinhVien WHERE MaSV = @maSV";
                sqlCmd.Parameters.AddWithValue("@maSV", maSV);
                sqlCmd.Connection = sqlCon;

                // Thực thi truy vấn
                SqlDataReader reader = sqlCmd.ExecuteReader();

                if (reader.Read())
                {
                    txtTenSV.Text = reader.GetString(1);
                    txtGioiTinh.Text = reader.GetString(2);
                    txtNgaySinh.Text = reader.GetDateTime(3).ToString("dd/MM/yyyy");
                    txtQueQuan.Text = reader.GetString(4);
                    txtMaLop.Text = reader.GetString(5);
                }
                else
                {
                    MessageBox.Show("Không tìm thấy sinh viên có mã: " + maSV, "Kết quả");
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo");
            }
        }
    }
}
