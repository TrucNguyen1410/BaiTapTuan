﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LAB4_TH2
{
    public partial class Form3 : Form
    {
        // 🔹 Chuỗi kết nối SQL Server (thay tên máy bạn nếu khác)
        string strCon = @"Data Source=DESKTOP-AV9ONFH\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True;";
        SqlConnection sqlCon = null;

        public Form3()
        {
            InitializeComponent();
        }

        // 🔹 Khi nhấn nút “Hiển thị danh sách sinh viên”
        private void btnXemDS_Click(object sender, EventArgs e)
        {
            try
            {
                // Mở kết nối
                if (sqlCon == null)
                    sqlCon = new SqlConnection(strCon);
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                // Xóa dữ liệu cũ trên ListView
                lsvSinhVien.Items.Clear();

                // Tạo truy vấn
                SqlCommand sqlCmd = new SqlCommand("SELECT * FROM SinhVien", sqlCon);

                // Thực thi và đọc dữ liệu
                SqlDataReader reader = sqlCmd.ExecuteReader();

                while (reader.Read())
                {
                    // Đọc từng dòng trong bảng SinhVien
                    string maSV = reader.GetString(0);
                    string tenSV = reader.GetString(1);
                    string gioiTinh = reader.GetString(2);
                    string ngaySinh = reader.GetDateTime(3).ToString("dd/MM/yyyy");
                    string queQuan = reader.GetString(4);
                    string maLop = reader.GetString(5);

                    // Thêm vào ListView
                    ListViewItem lvi = new ListViewItem(maSV);
                    lvi.SubItems.Add(tenSV);
                    lvi.SubItems.Add(gioiTinh);
                    lvi.SubItems.Add(ngaySinh);
                    lvi.SubItems.Add(queQuan);
                    lvi.SubItems.Add(maLop);
                    lsvSinhVien.Items.Add(lvi);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo");
            }
        }
    }
}
