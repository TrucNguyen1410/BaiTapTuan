﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LAB4_TH2
{
    public partial class Form5 : Form
    {
        // 🔹 Chuỗi kết nối SQL Server (thay lại cho đúng tên máy bạn)
        string strCon = @"Data Source=DESKTOP-AV9ONFH\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True;";
        SqlConnection sqlCon = null;

        public Form5()
        {
            InitializeComponent();
        }

        // 🔹 Khi Form5 mở — tải danh sách lớp vào ListBox
        private void Form5_Load(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon == null)
                    sqlCon = new SqlConnection(strCon);
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("SELECT * FROM Lop", sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();

                while (reader.Read())
                {
                    // Thêm lớp vào ListBox
                    string maLop = reader.GetString(0);
                    string tenLop = reader.GetString(1);
                    lsbDSLop.Items.Add(maLop + " - " + tenLop);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách lớp: " + ex.Message);
            }
        }

        // 🔹 Khi chọn một lớp → hiển thị sinh viên tương ứng
        private void lsbDSLop_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (lsbDSLop.SelectedItem == null)
                    return;

                // Lấy mã lớp (tách phần trước dấu '-')
                string maLop = lsbDSLop.SelectedItem.ToString().Split('-')[0].Trim();

                // Xóa dữ liệu cũ trong ListView
                lsvDSSV.Items.Clear();

                // Mở kết nối
                if (sqlCon == null)
                    sqlCon = new SqlConnection(strCon);
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                // Tạo lệnh truy vấn có parameter
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "SELECT MaSV, TenSV FROM SinhVien WHERE MaLop = @MaLop";
                sqlCmd.Parameters.AddWithValue("@MaLop", maLop);
                sqlCmd.Connection = sqlCon;

                // Thực thi truy vấn
                SqlDataReader reader = sqlCmd.ExecuteReader();
                while (reader.Read())
                {
                    string maSV = reader.GetString(0);
                    string tenSV = reader.GetString(1);

                    // Thêm từng sinh viên vào ListView
                    ListViewItem lvi = new ListViewItem(maSV);
                    lvi.SubItems.Add(tenSV);
                    lsvDSSV.Items.Add(lvi);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải danh sách sinh viên: " + ex.Message);
            }
        }
    }
}
